"""Call audio plumbing on PipeWire + ringtone.

When the phone's hands-free audio lands on the laptop, PipeWire exposes a source
(voice from the phone) and a sink (voice to the phone). If WirePlumber hasn't linked
them to the speakers / microphone, we bridge them with two pw-loopback processes.
"""
import json
import os
import shutil
import subprocess

from gi.repository import GLib

RINGTONES = [
    "/usr/share/sounds/freedesktop/stereo/phone-incoming-call.oga",
    "/usr/share/sounds/Yaru/stereo/phone-incoming-call.oga",
]


def _run(cmd, timeout=4):
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout).stdout
    except Exception:
        return ""


def pw_dump():
    out = _run(["pw-dump"], timeout=6)
    try:
        return json.loads(out) if out else []
    except ValueError:
        return []


def pipewire_version():
    out = _run(["pipewire", "--version"])
    for line in out.splitlines():
        if "libpipewire" in line:
            return line.split()[-1]
    for line in out.splitlines():
        if line.strip():
            return line.split()[-1]
    return "?"


def _props(o):
    return (o.get("info") or {}).get("props") or {}


class CallAudio:
    def __init__(self):
        self.procs = []
        self.mic_muted = False
        self._muted_default_source = False
        self._retry = None
        self.mac = ""

    # ---- discovery -------------------------------------------------------
    def _phone_nodes(self, dump):
        mac = self.mac.upper()
        src = sink = None
        for o in dump:
            if o.get("type") != "PipeWire:Interface:Node":
                continue
            p = _props(o)
            addr = (p.get("api.bluez5.address") or "").upper()
            name = p.get("node.name") or ""
            if not (addr == mac or mac.replace(":", "_") in name.upper()):
                continue
            prof = (p.get("api.bluez5.profile") or "").lower()
            if "a2dp" in prof or "a2dp" in name.lower():
                continue
            cls = p.get("media.class") or ""
            if "Source" in cls or "Output" in cls:
                src = o
            elif "Sink" in cls or "Input" in cls:
                sink = o
        return src, sink

    @staticmethod
    def _linked(dump, node_id, as_output):
        key = "output-node-id" if as_output else "input-node-id"
        for o in dump:
            if o.get("type") == "PipeWire:Interface:Link":
                if (o.get("info") or {}).get(key) == node_id:
                    return True
        return False

    @staticmethod
    def _default(dump, kind):
        for o in dump:
            if o.get("type") == "PipeWire:Interface:Metadata" and _props(o).get("metadata.name") == "default":
                for m in o.get("metadata") or []:
                    if m.get("key") == f"default.audio.{kind}":
                        v = m.get("value")
                        if isinstance(v, dict):
                            return v.get("name")
                        try:
                            return json.loads(v).get("name")
                        except Exception:
                            return None
        return None

    def _best_local(self, dump, cls, exclude):
        best, prio = None, -1
        for o in dump:
            if o.get("type") != "PipeWire:Interface:Node":
                continue
            p = _props(o)
            name = p.get("node.name") or ""
            if p.get("media.class") != cls or self.mac.replace(":", "_") in name.upper():
                continue
            if p.get("node.name") in exclude:
                continue
            pr = int(p.get("priority.session") or 0)
            if pr > prio:
                best, prio = p.get("node.name"), pr
        return best

    def _ensure_hfp_profile(self, dump):
        mac = self.mac.upper()
        for o in dump:
            if o.get("type") != "PipeWire:Interface:Device":
                continue
            if (_props(o).get("api.bluez5.address") or "").upper() != mac:
                continue
            params = (o.get("info") or {}).get("params") or {}
            cur = (params.get("Profile") or [{}])[0].get("name", "")
            if any(k in cur for k in ("audio-gateway", "headset", "hfp", "hsp")):
                return
            for prof in params.get("EnumProfile") or []:
                n = prof.get("name", "")
                if any(k in n for k in ("audio-gateway", "headset-head-unit", "hfp")):
                    _run(["wpctl", "set-profile", str(o["id"]), str(prof.get("index"))])
                    return

    def set_profile_off(self, mac):
        """Release the hands-free audio link: the iPhone then takes the audio back."""
        self.mac = mac or self.mac
        for o in pw_dump():
            if o.get("type") != "PipeWire:Interface:Device":
                continue
            if (_props(o).get("api.bluez5.address") or "").upper() != self.mac.upper():
                continue
            for prof in ((o.get("info") or {}).get("params") or {}).get("EnumProfile") or []:
                if prof.get("name") == "off":
                    _run(["wpctl", "set-profile", str(o["id"]), str(prof.get("index", 0))])
                    return True
        return False

    # ---- start / stop ----------------------------------------------------
    def start(self, mac):
        """Route call audio through the laptop. Retries while PipeWire creates the nodes."""
        self.mac = mac
        self.stop_routing()
        attempts = {"n": 0}

        def attempt():
            attempts["n"] += 1
            dump = pw_dump()
            self._ensure_hfp_profile(dump)
            src, sink = self._phone_nodes(dump)
            if not src and not sink:
                return attempts["n"] < 30   # keep trying ~15 s
            self._bridge(dump, src, sink)
            self._retry = None
            return False

        self._retry = GLib.timeout_add(500, attempt)

    def _bridge(self, dump, src, sink):
        lb = shutil.which("pw-loopback")
        if not lb:
            return
        if src and not self._linked(dump, src["id"], True):
            out_sink = self._default(dump, "sink")
            if not out_sink or self.mac.replace(":", "_") in (out_sink or "").upper():
                out_sink = self._best_local(dump, "Audio/Sink", ())
            cmd = [lb, "-n", "lica-from-iphone",
                   "--capture-props", f'target.object="{_props(src).get("node.name")}" node.dont-reconnect=true node.passive=false',
                   "--playback-props", "media.role=Communication node.description=\"iPhone call\"" +
                   (f' target.object="{out_sink}"' if out_sink else "")]
            self.procs.append(subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
        if sink and not self._linked(dump, sink["id"], False):
            mic = self._default(dump, "source")
            if not mic or self.mac.replace(":", "_") in (mic or "").upper():
                mic = self._best_local(dump, "Audio/Source", ())
            cmd = [lb, "-n", "lica-to-iphone",
                   "--capture-props", "media.role=Communication node.description=\"iPhone call mic\"" +
                   (f' target.object="{mic}"' if mic else ""),
                   "--playback-props", f'target.object="{_props(sink).get("node.name")}" node.dont-reconnect=true']
            self.procs.append(subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
        if self.mic_muted:
            self.set_mute(True)

    def stop_routing(self):
        if self._retry:
            GLib.source_remove(self._retry)
            self._retry = None
        for p in self.procs:
            try:
                p.terminate()
            except Exception:
                pass
        self.procs = []

    def stop(self):
        self.stop_routing()
        if self.mic_muted:
            self.set_mute(False)
        self.mic_muted = False

    # ---- mute ------------------------------------------------------------
    def set_mute(self, on):
        self.mic_muted = on
        dump = pw_dump()
        _src, sink = self._phone_nodes(dump) if self.mac else (None, None)
        targets = [o["id"] for o in dump
                   if o.get("type") == "PipeWire:Interface:Node"
                   and _props(o).get("node.name", "").startswith("lica-to-iphone")
                   and _props(o).get("media.class", "").startswith("Stream/Input")]
        if sink is not None:
            targets.append(sink["id"])
        for t in targets:
            _run(["wpctl", "set-mute", str(t), "1" if on else "0"])
        if on and not targets:
            _run(["wpctl", "set-mute", "@DEFAULT_AUDIO_SOURCE@", "1"])
            self._muted_default_source = True
        if not on and self._muted_default_source:
            _run(["wpctl", "set-mute", "@DEFAULT_AUDIO_SOURCE@", "0"])
            self._muted_default_source = False


class Ringer:
    def __init__(self):
        self.proc = None
        self.timer = None
        self.file = next((f for f in RINGTONES if os.path.exists(f)), None)
        self.player = shutil.which("pw-play") or shutil.which("paplay") or shutil.which("canberra-gtk-play")

    def start(self):
        if self.timer or not self.file or not self.player:
            return
        self._play()
        self.timer = GLib.timeout_add(3200, self._play)

    def _play(self):
        if self.proc and self.proc.poll() is None:
            return True
        args = [self.player, "-f", self.file] if self.player.endswith("canberra-gtk-play") else [self.player, self.file]
        try:
            self.proc = subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except OSError:
            pass
        return True

    def stop(self):
        if self.timer:
            GLib.source_remove(self.timer)
            self.timer = None
        if self.proc and self.proc.poll() is None:
            self.proc.terminate()
        self.proc = None
